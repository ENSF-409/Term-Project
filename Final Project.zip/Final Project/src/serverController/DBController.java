package serverController;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import serverModel.*;

public class DBController implements IDBCredentials, Constants{
	
	private Connection conn;
	private ResultSet rs;
	
	public DBController() {
		initializeConnection();
		createStudentTable();
		//createCourseTable();
		//createRegistrationTable();
	}

	private void initializeConnection(){
		try {
		
			Driver driver = new com.mysql.cj.jdbc.Driver();
			DriverManager.registerDriver(driver);
			conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}
	
	private void close() {
		try {
			// rs.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void createStudentTable() {
		String sql = "CREATE TABLE STUDENT " + "(id INTEGER not NULL, " + " name "
				+ "VARCHAR(255), " + " PRIMARY KEY ( id ))";
		populateStudentTable();
		try {
			Statement stmt = conn.createStatement(); 
			stmt.executeUpdate(sql); 
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void createCourseTable() {
		String sql = "CREATE TABLE COURSE " + "(name VARCHAR(255), " + " num INTEGER"
				+ " not NULL, " + "sec INTEGER null NULL, " +" PRIMARY KEY ( id ))";
		try {
			Statement stmt = conn.createStatement(); 
			stmt.executeUpdate(sql); 
			stmt.close();
			populateCourseTable();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void createRegistrationTable() {
		String sql = "CREATE TABLE REGISTRATION " + "(studentId INTEGER not NULL, " 
				+ " courseId INTEGER not NULL, " + " PRIMARY KEY ( id ))";
		try {
			Statement stmt = conn.createStatement(); 
			stmt.executeUpdate(sql); 
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void populateStudentTable() {
		insertStudent(123, "John");
		insertStudent(343, "Mary");
		insertStudent(345, "Niyousha");
		insertStudent(987, "Dunsin");
		insertStudent(453, "Francis");
		insertStudent(278, "Joy");
		insertStudent(145, "Prince");
		insertStudent(943, "Helen");
	}
	
	private void insertStudent(int id, String name) {
		try {
			String query = "INSERT INTO STUDENT (ID, name) values (?,?)";
			PreparedStatement pStat = conn.prepareStatement(query);
			pStat.setInt(1, id);
			pStat.setString(2, name);
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void populateCourseTable() {
		insertCourse("ENGG", 233, NUMSECTIONS);
		insertCourse("ENSF", 409, NUMSECTIONS);
		insertCourse("PHYS", 259, NUMSECTIONS);
		insertCourse("ENGG", 209, NUMSECTIONS);
		insertCourse("ENGG", 213, NUMSECTIONS);
		insertCourse("CHEM", 209, NUMSECTIONS);
		insertCourse("MATH", 211, NUMSECTIONS);
		insertCourse("MATH", 275, NUMSECTIONS);
		insertCourse("MATH", 277, NUMSECTIONS);
		insertCourse("ENGG", 201, NUMSECTIONS);
		insertCourse("ENGG", 200, NUMSECTIONS);
		insertCourse("ENGG", 225, NUMSECTIONS);
		insertCourse("ENGG", 202, NUMSECTIONS);
	}
	
	public void insertCourse(String courseName, int courseNum, int courseSec) {
		try {
			String query = "INSERT INTO COURSE (name, num, sec) values (?,?,?)";
			PreparedStatement pStat = conn.prepareStatement(query);
			pStat.setString(1, courseName);
			pStat.setInt(2, courseNum);
			pStat.setInt(3, courseSec);
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void insertRegistration(int studentId, int courseId) {
		try {
			String query = "INSERT INTO REGISTRATION (studentId, courseId) values (?,?)";
			PreparedStatement pStat = conn.prepareStatement(query);
			pStat.setInt(1, studentId);
			pStat.setInt(2, courseId);
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		DBController dbController = new DBController();
	}
}
