package serverController;

import java.util.Random;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import serverModel.*;

public class DBController implements IDBCredentials, Constants{
	
	private Connection conn;
	private ResultSet rs;
	
	public DBController() {
		initializeConnection();
		createStudentTable();
		//createCourseTable();
		createRegistrationTable();
	}

	private void initializeConnection(){
		try {
		
			Driver driver = new com.mysql.cj.jdbc.Driver();
			DriverManager.registerDriver(driver);
			conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}
	
	private void close() {
		try {
			// rs.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void createStudentTable() {
		String sql = "CREATE TABLE STUDENT " + "(id INTEGER not NULL, " + " name "
				+ "VARCHAR(255), " + " PRIMARY KEY ( id ))";
		populateStudentTable();
		try {
			Statement stmt = conn.createStatement(); 
			stmt.executeUpdate(sql); 
			stmt.close();
			populateStudentTable();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void createCourseTable() {
		String sql = "CREATE TABLE COURSE " + " (id INTEGER not NULL, " + " name VARCHAR(255), " + 
					 "sec INTEGER null NULL, " + " PRIMARY KEY ( id ))";
		try {
			Statement stmt = conn.createStatement(); 
			stmt.executeUpdate(sql); 
			stmt.close();
			populateCourseTable();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void createRegistrationTable() {
		String sql = "CREATE TABLE REGISTRATION " + " (id INTEGER not NULL, " + " studentId INTEGER not NULL, " 
				+ "courseId INTEGER not NULL, " + " PRIMARY KEY ( id ))";
		try {
			Statement stmt = conn.createStatement(); 
			stmt.executeUpdate(sql); 
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void populateStudentTable() {
		insertStudent(123, "John");
		insertStudent(343, "Mary");
		insertStudent(345, "Niyousha");
		insertStudent(987, "Dunsin");
		insertStudent(453, "Francis");
		insertStudent(278, "Joy");
		insertStudent(145, "Prince");
		insertStudent(943, "Helen");
	}
	
	private void insertStudent(int studentId, String studentName) {
		try {
			String query = "INSERT INTO STUDENT (id, name) values (?,?)";
			PreparedStatement pStat = conn.prepareStatement(query);
			pStat.setInt(1, studentId);
			pStat.setString(2, studentName);
			pStat.execute();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void populateCourseTable() {
		insertCourse("ENGG 233", NUMSECTIONS);
		insertCourse("ENSF 409", NUMSECTIONS);
		insertCourse("PHYS 259", NUMSECTIONS);
		insertCourse("ENGG 209", NUMSECTIONS);
		insertCourse("ENGG 213", NUMSECTIONS);
		insertCourse("CHEM 209", NUMSECTIONS);
		insertCourse("MATH 211", NUMSECTIONS);
		insertCourse("MATH 275", NUMSECTIONS);
		insertCourse("MATH 277", NUMSECTIONS);
		insertCourse("ENGG 201", NUMSECTIONS);
		insertCourse("ENGG 200", NUMSECTIONS);
		insertCourse("ENGG 225", NUMSECTIONS);
		insertCourse("ENGG 202", NUMSECTIONS);
	}
	
	public void insertCourse(String course, int courseSec) {
		for (int i = 0; i < courseSec; i++) {
			insertCourseSection(generateRandomId(), course, i);
		}
	}
	
	private int generateRandomId() {
		Random rand = new Random();
		int generatedId = rand.nextInt(500);
		while (doesIdExist(generatedId)) {
			generatedId = rand.nextInt(500);
		}
		return generatedId;
	}
	
	private boolean doesIdExist(int generatedId) {
		try {
			String query = "SELECT * FROM COURSE";
			PreparedStatement pStat = conn.prepareStatement(query);
			rs = pStat.executeQuery();
			
			while (rs.next()) {
				if (rs.getInt("id") == generatedId)
					return true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	private void insertCourseSection(int courseId, String course, int secNum) {
			try {
			String query = "INSERT INTO COURSE (id, name, sec) values (?,?,?)";
			PreparedStatement pStat = conn.prepareStatement(query);
			pStat.setInt(1, courseId);
			pStat.setString(2, course);
			pStat.setInt(3, secNum);
			pStat.execute();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void removeCourse(int courseId) {
		String query = "DELETE FROM COURSE where id = '" + courseId;
		try {
			PreparedStatement pStat = conn.prepareStatement(query);
			pStat.setInt(1, courseId);
			pStat.execute();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void insertRegistration(int registrationId, int studentId, int courseId) {
		try {
			String query = "INSERT INTO REGISTRATION (id, studentId, courseId) values (?,?,?)";
			PreparedStatement pStat = conn.prepareStatement(query);
			pStat.setInt(1, registrationId);
			pStat.setInt(2, studentId);
			pStat.setInt(3, courseId);
			pStat.execute();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void removeRegistration (int registrationId) {
		String query = "DELETE FROM REGISTRATION where id = '" + registrationId;
		try {
			PreparedStatement pStat = conn.prepareStatement(query);
			pStat.setInt(1, registrationId);
			pStat.execute();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static void main(String[] args) {
		DBController dbController = new DBController();
	}
}
