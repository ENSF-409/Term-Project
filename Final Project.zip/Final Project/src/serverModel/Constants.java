/**
 * @author Dunsin Shitta-Bey
 * @author Niyousha Raeesinejad
 */

package serverModel;

public interface Constants {
	static final int MAXCOURSES = 6;
	static final int MINREG = 8;
	static final int NUMSECTIONS = 4;
	static final int CAPACITY = 100;
}
