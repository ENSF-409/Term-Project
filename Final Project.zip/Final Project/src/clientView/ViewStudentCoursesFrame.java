/**
 * @author Niyousha Raeesinejad
 * @author Dunsin Shitta-Bey
 */

package clientView;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class ViewStudentCoursesFrame extends JFrame {
	private Container c;
	private JTextArea textArea;
	private JPanel pSouth, pCenter;
	private JButton returnToMain;
	private JScrollPane scrollPanel;
	
	public ViewStudentCoursesFrame() {
		super("View My Courses");
		setBounds(400, 350, 700, 300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		c = getContentPane();
		c.setLayout(new BorderLayout());
		
		// South Panel
		pSouth = new JPanel(new FlowLayout(FlowLayout.RIGHT));
		returnToMain = new JButton("Return");
		pSouth.add(returnToMain);
		c.add("South", pSouth);
	}

	public void setTextArea(String studentCourses) {
		// Center Text Area
		pCenter = new JPanel();
		textArea = new JTextArea();
		textArea.setFont(new Font("Arial", Font.BOLD, 15));
		textArea.setEditable(false);
		pCenter.add(textArea);
		textArea.setText(studentCourses);
		textArea.setLineWrap(false); // may not need
		scrollPanel = new JScrollPane(textArea);
		c.add(scrollPanel, BorderLayout.CENTER);
		//pack();
	}
	
	public JButton getReturnToMainButton() {
		return returnToMain;
	}
}
