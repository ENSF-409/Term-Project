/**
 * @author Niyousha Raeesinejad
 * @author Dunsin Shitta-Bey
 */

package clientController;

import clientView.*;
import clientModel.*;

import java.awt.event.ActionEvent;
import javax.swing.JButton;
import javax.swing.JFrame;

// TODO Documentation

public class GUIController {
	private LoginFrame loginFrame;
	private MainFrame mainFrame;
	private SearchCourseFrame searchCourseFrame;
	private ViewAllCoursesFrame viewAllCoursesFrame;
	private ViewStudentCoursesFrame viewStudentCoursesFrame;
	private CourseDisplayFrame courseDisplayFrame;
	private Student theStudent;
	private ComController comController;
	
	public GUIController(){
		comController = new ComController();
		loginFrame = new LoginFrame();
		loginFrame.setVisible(true);
		loginFrameEventHandler(loginFrame.getLoginButton());
		mainFrame = new MainFrame();
		mainFrameEventHandler(mainFrame.getViewAllCoursesButton(), mainFrame.getViewStudentCoursesButton());
	}

	private void setVisibleFrame(JFrame visibleFrame, JFrame invisibleFrame) {
		visibleFrame.setVisible(true);
		invisibleFrame.setVisible(false);
	}
	
	private void switchToMainFrame(JFrame disposeFrame) {
		disposeFrame.dispose();
		mainFrame.setVisible(true);
	}
	
	// TODO Complete event handlers
	
	private void loginFrameEventHandler(JButton login) {
		login.addActionListener((ActionEvent e) ->{
			setStudent(loginFrame.getName(), loginFrame.getId());

			if(verifyAction(searchStudent())){
				mainFrame.setInstructionMessage(theStudent.getStudentName());
				switchToMainFrame(loginFrame);
				
			}else {
				loginFrame.displayErrorMessage("Invalid!");
				
			}			
		});	
	}

	private void mainFrameEventHandler(JButton viewAllCourses, JButton viewStudentCourses) {
				
		viewAllCourses.addActionListener((ActionEvent e) ->{
			viewAllCoursesFrame = new ViewAllCoursesFrame();
			String courses = getCourseCatalogue();
			viewAllCoursesFrame.setTextArea(courses);
			setVisibleFrame(viewAllCoursesFrame, mainFrame);
			viewAllCoursesEventHandler(viewAllCoursesFrame.getReturnToMainButton(), viewAllCoursesFrame.getSearchCourse());
		});
				
		viewStudentCourses.addActionListener((ActionEvent e) ->{
			String studentCourses = getStudentCourses(theStudent);
			viewStudentCoursesFrame = new ViewStudentCoursesFrame();
			
			if(studentCourses.isBlank()) 
				studentCourses = theStudent.getStudentName() + " is not enrolled in any courses yet!";
			
			viewStudentCoursesFrame.setTextArea(studentCourses);
			setVisibleFrame(viewStudentCoursesFrame, mainFrame);
			viewStudentCoursesEventHandler(viewStudentCoursesFrame.getReturnToMainButton());
		});
	}
	
	private void searchCourseFrameEventHandler(JButton returnToMainButton, JButton okButton) {
		returnToMainButton.addActionListener((ActionEvent e) ->{
			setVisibleFrame(viewAllCoursesFrame, searchCourseFrame);
		});
				
		okButton.addActionListener((ActionEvent e) ->{
			while(!verifyCourse(searchCourse(searchCourseFrame.getCourseName(), searchCourseFrame.getCourseNum()))) {
				searchCourseFrame.displayMessage("Course does not exist!");
				return;
			}
			courseDisplayFrame = new CourseDisplayFrame();
			System.out.println(searchCourseFrame.getCourseName() + " " + searchCourseFrame.getCourseNum());
			courseDisplayFrame.setCourseTextArea(searchCourseFrame.getCourseName(), searchCourseFrame.getCourseNum());
			setVisibleFrame(courseDisplayFrame, searchCourseFrame);
			courseDisplayEventHandler(courseDisplayFrame.getReturnToSearchCourseButton(), courseDisplayFrame.getAddCourseButton(), courseDisplayFrame.getRemoveCourseButton());
		});
	}

	public void courseDisplayEventHandler(JButton returnButton, JButton addCourseButton, JButton removeCourseButton) {
		
		returnButton.addActionListener((ActionEvent e) ->{
			setVisibleFrame(searchCourseFrame, courseDisplayFrame);
		});
		
		addCourseButton.addActionListener((ActionEvent e) ->{
			System.out.println("Course added!");
			String added = addCourse(courseDisplayFrame.getCourseName(), courseDisplayFrame.getCourseNum(), courseDisplayFrame.getSecNum());
			if(verifyAction(added))
				courseDisplayFrame.displayMessage("Course added successfully!");
			else {
				courseDisplayFrame.displayMessage(added); // error message from addCourse on server end sent as string
				setVisibleFrame(searchCourseFrame, courseDisplayFrame);
			}
			setVisibleFrame(viewAllCoursesFrame, courseDisplayFrame);
		});
		
		removeCourseButton.addActionListener((ActionEvent e) ->{
			System.out.println("Remove course!");
			String removed = removeCourse(courseDisplayFrame.getCourseName(), courseDisplayFrame.getCourseNum(), courseDisplayFrame.getSecNum());
			if (verifyAction(removed))
				courseDisplayFrame.displayMessage("Course removed successfully!");
			else {
				courseDisplayFrame.displayMessage(removed); // error message from addCourse on server end sent as string
				setVisibleFrame(searchCourseFrame, courseDisplayFrame);
			}
			setVisibleFrame (viewAllCoursesFrame, courseDisplayFrame);
		});
	}

	public void viewAllCoursesEventHandler(JButton returnToMainButton, JButton searchCourseButton) {
		returnToMainButton.addActionListener((ActionEvent e) ->{
			switchToMainFrame(viewAllCoursesFrame);
		});
		
		searchCourseButton.addActionListener((ActionEvent e) ->{
			System.out.println("Search for courses!");
			searchCourseFrame = new SearchCourseFrame();
			setVisibleFrame(searchCourseFrame, viewAllCoursesFrame);
			searchCourseFrameEventHandler(searchCourseFrame.getReturnToMainButton(), searchCourseFrame.getOkButton());
		});

	}
	
	public void viewStudentCoursesEventHandler(JButton returnToMainButton) {
		returnToMainButton.addActionListener((ActionEvent e) ->{
			switchToMainFrame(viewStudentCoursesFrame);
		});
	}

	// Case 1
	private String searchCourse(String courseName, String courseNum) {
		return comController.searchCourse(courseName, courseNum);
	}

	// Case 2
	private String addCourse(String courseName, String courseNum, String secNum) {
		return comController.addCourse(theStudent.getStudentName(), theStudent.getStudentId(), courseName, courseNum, secNum);
	}
	
	// Case 3
	private String removeCourse(String courseName, String courseNum, String secNum) {
		return comController.removeCourse(theStudent.getStudentName(), theStudent.getStudentId(), courseName, courseNum, secNum);
	}
	
	// Case 4
	private String getCourseCatalogue() {
		return comController.getCourseCatalogue();
	}
	
	// Case 5
	private String getStudentCourses(Student theStudent) {
		return comController.getStudentCourses(theStudent);
	}
	
	// Case 6
	private String searchStudent() {
		return comController.searchStudent(theStudent);
	}

	private boolean verifyCourse(String searchCourse) {
		if (searchCourse == null)
			return false;
		else
			return true;
	}
	
	private boolean verifyAction(String valid) {
		if (valid.equalsIgnoreCase("valid"))
				return true;
		else
			return false;
	}
	
	private void setStudent(String name, int id) {
		theStudent = new Student(name, id);
	}
	
	public static void main(String []args) {
		GUIController GUI = new GUIController();
	}
}
