ENSF409 Final Project Milestone 2
Niyousha Raeesinejad
Dunsin Shitta-Bey

Arrangement of project

Final Project -->
		src -->
			clientController (Package)			   		
			clientModel (Package)		
			clientView (Package)		
			serverController(Package)	
			serverModel (Package) 		
				  	    
	

To run this student course registration program please go through the following sequence:

1] Extract the Final Project from the zip folder onto an IDE (preferably eclipse)

2] Run ServerCommsController.java from the serverController package

3] Then run the GUIController.java file from the clientController package

4] Follow the instructions on the GUI
