/**
 * @author Dunsin Shitta-Bey
 * @author Niyousha Raeesinejad
 */

package serverModel;

import java.util.ArrayList;

import serverController.DBController;

// TODO change to implement database

//This class is simulating a database for our
//program
public class DBManager implements Constants {

	ArrayList <Course> courseList;
	ArrayList <Student> studentList;
	private DBController dbController;

	public DBManager () {
		dbController = new DBController();
		init();
	}
	
	private void init() {
		studentList = dbController.populateStudentListFromTable();
		//System.out.println("Success\n" + sendStudentList());
		courseList = dbController.populateCourseListFromTable();
		//System.out.println("Success\n" + sendCourseList());
		
	}
	
	public String sendStudentList(){
		String s = "All the students currently in the data base are:\n";
		for(Student student : studentList){
			s += student.toString() + "\n";
		}
		return s;
	}
	
	public String sendCourseList(){
		String s = "All the courses currently in the data base are:\n";
		for(Course course : courseList){
			s += course.toString() + "\n";
		}
		return s;
	}
		
	
	public Student findStudent(String studentName, int studentId) {
		for (Student s: studentList) {
			if (s.getStudentName().equalsIgnoreCase(studentName) && s.getStudentId() == studentId)
				return s;
		}
		
		return null;
	}
	
	public Course findCourse(String courseName, int courseNum) {
		for (Course c: courseList) {
			if (c.getCourseName().equalsIgnoreCase(courseName) && c.getCourseNum() == courseNum)
				return c;
		}
		return null;
	}
	
	public ArrayList<Student> readStudentListFromDataBase() {
		studentList = dbController.populateStudentListFromTable();	
		return studentList;
	}
	
	public void updateStudentListFromDataBase() {
		studentList = dbController.populateStudentListFromTable();	
	}
	
	public void updateCourseListFromDataBase() {
		courseList = dbController.populateCourseListFromTable();
	}
	
	public ArrayList<Student> getStudentListFromDataBase() {
		studentList = dbController.populateStudentListFromTable();	
		return studentList;
	}
	
	public ArrayList<Course> readCourseListFromDataBase() {
		courseList = dbController.populateCourseListFromTable();
		return courseList;
	}

	public DBController getDBController() {
		return dbController;
	}
}
