package serverController;

public interface IDBCredentials {
	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";  
	static final String DB_URL = "jdbc:mysql://localhost/studentcourseregistrationsystem";
	   
	// Database credentials
	static final String USERNAME = "root";
	static final String PASSWORD = "akinlode";
}
