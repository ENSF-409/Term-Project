package serverController;

import java.util.ArrayList;
import java.util.Random;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import serverModel.*;

public class DBController implements IDBCredentials, Constants{
	
	private Connection conn;
	private ResultSet rs;
	
	public DBController() {
		initializeConnection();
		init();
	}

	
	private void init() {
		createStudentTable();
		createCourseTable();
		createRegistrationTable();
	}
	
	private void initializeConnection(){
		try {
		
			Driver driver = new com.mysql.cj.jdbc.Driver();
			DriverManager.registerDriver(driver);
			conn = DriverManager.getConnection(DB_URL, USERNAME, PASSWORD);
			
		} catch (SQLException e) {
			e.printStackTrace();
		}	
	}
	
	private void close() {
		try {
			// rs.close();
			conn.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void createStudentTable() {
		String sql = "CREATE TABLE STUDENT " + "(id INTEGER not NULL, " + " name "
				+ "VARCHAR(255), " + " PRIMARY KEY ( id ))";
		//populateStudentTable();
		try {
			Statement stmt = conn.createStatement(); 
			stmt.executeUpdate(sql); 
			stmt.close();
			populateStudentTable();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void createCourseTable() {
		String sql = "CREATE TABLE COURSE " + " (id INTEGER not NULL, " + " name VARCHAR(255), " + 
					 "sec INTEGER not NULL, " + " PRIMARY KEY ( id ))";
		try {
			Statement stmt = conn.createStatement(); 
			stmt.executeUpdate(sql); 
			stmt.close();
			populateCourseTable();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void createRegistrationTable() {
		String sql = "CREATE TABLE REGISTRATION " + " (id INTEGER not NULL, " + " studentId INTEGER not NULL, " 
				+ "courseId INTEGER not NULL, " + " PRIMARY KEY ( id ))";
		try {
			Statement stmt = conn.createStatement(); 
			stmt.executeUpdate(sql); 
			stmt.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private void populateStudentTable() {
		insertStudent(123, "John");
		insertStudent(343, "Mary");
		insertStudent(345, "Niyousha");
		insertStudent(987, "Dunsin");
		insertStudent(453, "Francis");
		insertStudent(278, "Joy");
		insertStudent(145, "Prince");
		insertStudent(943, "Helen");
	}
	
	
	public ArrayList <Student> populateStudentListFromTable() {
		ArrayList <Student> studentList = new ArrayList <Student>();
		try {
			String query = "SELECT * FROM STUDENT";
			PreparedStatement pStat = conn.prepareStatement(query);
			rs = pStat.executeQuery();
			while (rs.next()) {
				studentList.add(new Student(rs.getString("name"), rs.getInt("id")));
				
			}
			
		for(Student s: studentList) {
			updateStudent(s);
			//System.out.println("FIRST TIME " + s);
		}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return studentList;
	}
	
	
	public void updateStudent(Student theStudent) {
		ArrayList<Registration> studentRegList = new ArrayList<Registration>();
		try {
			String query = "SELECT * FROM REGISTRATION";
			PreparedStatement pStat = conn.prepareStatement(query);
			rs = pStat.executeQuery();
			
			while (rs.next()) {
				if(rs.getInt("studentId") == theStudent.getStudentId()) {
					int keyId = rs.getInt("courseId");
					String regDetails[] = getCourse(keyId).split(" ");
					if(regDetails.length == 3) {
						String courseName = regDetails[0];
						int courseNum = Integer.parseInt(regDetails[1]);
						int secNum = Integer.parseInt(regDetails[2]);
						System.out.println("Adding " + courseName + " " + courseNum + " sec " + secNum + " to " +  theStudent.getStudentName());
						Registration reg = new Registration();
						reg.setTheStudent(theStudent);
						Course c = new Course(courseName, courseNum);
						CourseOffering cOffer = new CourseOffering(c, secNum, CAPACITY, keyId);
						c.addOffering(cOffer);
						reg.setTheOffering(cOffer);
						theStudent.addRegistration(reg);
						cOffer.addRegistration(reg);
						studentRegList.add(reg);
					}
					 
				}
			}
			theStudent.updateFromDB(studentRegList);
			

		}catch (SQLException e) {
		e.printStackTrace();
		}
	
	}
	
	private String getCourse(int id) {
		String s = "";
		try {
			String query = "SELECT * FROM COURSE";
			PreparedStatement pStat = conn.prepareStatement(query);
			rs = pStat.executeQuery();
			
			while (rs.next()) {
				if(rs.getInt("id") == id) {
					s = rs.getString("name") + " " + rs.getInt("sec");
				}
			}
		}catch (SQLException e) {
		e.printStackTrace();
		}
		return s;

	}
	
	
	private void insertStudent(int studentId, String studentName) {
		if(studentAlreadyExists(studentId)) return;
		try {
			String query = "INSERT INTO STUDENT (id, name) values (?,?)";
			PreparedStatement pStat = conn.prepareStatement(query);
			pStat.setInt(1, studentId);
			pStat.setString(2, studentName);
			pStat.execute();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	private boolean studentAlreadyExists(int studentId) {
		try {
			String query = "SELECT * FROM STUDENT";
			PreparedStatement pStat = conn.prepareStatement(query);
			rs = pStat.executeQuery();
			
			while (rs.next()) {
				if (rs.getInt("id") == studentId)
					return true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	private void populateCourseTable() {
		
		insertCourse("ENGG 233", NUMSECTIONS);
		insertCourse("ENSF 409", NUMSECTIONS);
		insertCourse("PHYS 259", NUMSECTIONS);
		insertCourse("ENGG 209", NUMSECTIONS);
		insertCourse("ENGG 213", NUMSECTIONS);
		insertCourse("CHEM 209", NUMSECTIONS);
		insertCourse("MATH 211", NUMSECTIONS);
		insertCourse("MATH 275", NUMSECTIONS);
		insertCourse("MATH 277", NUMSECTIONS);
		insertCourse("ENGG 201", NUMSECTIONS);
		insertCourse("ENGG 200", NUMSECTIONS);
		insertCourse("ENGG 225", NUMSECTIONS);
		insertCourse("ENGG 202", NUMSECTIONS);
	}
	
	public boolean insertCourse(String course, int courseSec) {
		if(courseAlreadyExists(course)) return false;
		for (int i = 0; i < courseSec; i++) {
			insertCourseSection(generateRandomId(), course, i);
		}
		return true;
	}
	
	public boolean addCourse(String course, int courseSec) {
		return insertCourse(course, courseSec);
	}
	
	private boolean courseAlreadyExists(String course) {
		try {
			String query = "SELECT * FROM COURSE";
			PreparedStatement pStat = conn.prepareStatement(query);
			rs = pStat.executeQuery();
			
			while (rs.next()) {
				if (rs.getString("name").equals(course))
					return true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	
	private int generateRandomId() {
		//Random rand = new Random();
		//int generatedId = rand.nextInt(500);
		int generatedId = 1;
		while (doesIdExist(generatedId)) {
			//generatedId = rand.nextInt(500);
			generatedId ++;
		}
		return generatedId;
	}
	
	private boolean doesIdExist(int generatedId) {
		try {
			String query = "SELECT * FROM COURSE";
			PreparedStatement pStat = conn.prepareStatement(query);
			rs = pStat.executeQuery();
			
			while (rs.next()) {
				if (rs.getInt("id") == generatedId)
					return true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	private void insertCourseSection(int courseId, String course, int secNum) {
			try {
			String query = "INSERT INTO COURSE (id, name, sec) values (?,?,?)";
			PreparedStatement pStat = conn.prepareStatement(query);
			pStat.setInt(1, courseId);
			pStat.setString(2, course);
			pStat.setInt(3, secNum);
			pStat.execute();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public boolean removeCourse(String course, int sec) {
		try {
			String query = "SELECT * FROM COURSE";
			PreparedStatement pStat = conn.prepareStatement(query);
			rs = pStat.executeQuery();
			
			while (rs.next()) {
				if(rs.getString("name").equals(course)) {
					removeCourse(rs.getInt("id"));
				}
			}
			return true;
		}catch (SQLException e) {
		e.printStackTrace();
		}
		return false;

	}
	
	private void removeCourse(int courseId) {
		String query = "DELETE FROM COURSE where id = ?";
		try {
			PreparedStatement pStat = conn.prepareStatement(query);
			pStat.setInt(1, courseId);
			pStat.execute();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	
	public ArrayList <Course> populateCourseListFromTable() {
		ArrayList <Course> courseList = new ArrayList <Course>();
		Course c = null;
		try {
			String query = "SELECT * FROM COURSE";
			PreparedStatement pStat = conn.prepareStatement(query);
			rs = pStat.executeQuery();
			int sectionOffering;
			int sqlId;
			String initialCourse;
			while (rs.next()) {
				initialCourse = rs.getString("name");
				String[] courseVals = initialCourse.split(" ");
				sectionOffering = rs.getInt("sec");
				sqlId = rs.getInt("id");
				
				
				if(courseVals.length == 2) {
					c = new Course(courseVals[0], Integer.parseInt(courseVals[1]));	
					c.addOffering(new CourseOffering(c, sectionOffering, CAPACITY, sqlId));
					//System.out.println(courseVals[0] + courseVals[1]);
				}
				
				
				int checker = 0;
				for(Course course:  courseList) {
					if(course.getCourseName().equals(courseVals[0]) && course.getCourseNum() == Integer.parseInt(courseVals[1])) {
						checker++;
						//System.out.println("\nChecker = " + checker);
						course.addOffering(new CourseOffering(c, sectionOffering, CAPACITY, sqlId));
						//System.out.println("IN CHECKER++ /n" + c);
						
					}
				}
				if(checker == 0 && courseVals.length == 2) {
					//System.out.println("\nChecker = " + checker);
					courseList.add(c);
					//System.out.println("IN CHECKER = 0 /n" + c);
					
				}
				}
				
				
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return courseList;
	}
	
	
	public void insertRegistration(int registrationId, int studentId, int courseId) {
		if(doesRegExist(registrationId)) return;
		try {
			String query = "INSERT INTO REGISTRATION (id, studentId, courseId) values (?,?,?)";
			PreparedStatement pStat = conn.prepareStatement(query);
			pStat.setInt(1, registrationId);
			pStat.setInt(2, studentId);
			pStat.setInt(3, courseId);
			pStat.execute();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public void removeRegistration (int registrationId) {
		String query = "DELETE FROM REGISTRATION where id = '" + registrationId;
		try {
			PreparedStatement pStat = conn.prepareStatement(query);
			pStat.setInt(1, registrationId);
			pStat.execute();
			pStat.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	private boolean doesRegExist(int regId) {
		try {
			String query = "SELECT * FROM REGISTRATION";
			PreparedStatement pStat = conn.prepareStatement(query);
			rs = pStat.executeQuery();
			
			while (rs.next()) {
				if (rs.getInt("id") == regId)
					return true;
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}
	
	
	public static void main(String[] args) {
		DBController dbController = new DBController();
	}
}
