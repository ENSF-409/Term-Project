/**
 * @author Dunsin Shitta-Bey
 * @author Niyousha Raeesinejad
 */

package serverController;

import serverModel.*;

import java.io.IOException;
import java.net.ServerSocket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ServerCommsController{
	
	private ServerSocket serverSocket; //socket to connect server with client
	private ExecutorService threadPool; //create multiple threads for different users to use services at the same time
	
	public ServerCommsController(int port){
		try{
			serverSocket = new ServerSocket(port); //port should be same as client [9090]
			threadPool = Executors.newCachedThreadPool(); //create threads as needed
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	public void communicateWithClient() throws IOException{
		try {
			while(true) {
				BackEnd theBackEnd = new BackEnd(serverSocket.accept()); //Creates new BackEnd instance for every new ComController
				threadPool.execute(theBackEnd);
			}
		}catch(Exception e) {
			e.printStackTrace();
			threadPool.shutdown();
		}
	}

	public static void main(String args[]) {
		ServerCommsController myServerController = new ServerCommsController(9090);
		try {
			myServerController.communicateWithClient();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
